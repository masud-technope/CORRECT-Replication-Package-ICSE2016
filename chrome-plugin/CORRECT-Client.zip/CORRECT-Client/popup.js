var google = new OAuth2('github', {
  client_id: 'd1a2b8133b6b091473eb',
  client_secret: '38ef7b817d3cf80c1d2680988f9d642c907221bb',
  api_scope: 'user,repo'
});

google.authorize(function() {
  var GITHUB_USER_URL='https://api.github.com/user';
  // Make an XHR that retrieve activities with YouTube Data API
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function(event) {
    if (xhr.readyState == 4) {
      if(xhr.status == 200) {
		  var response=xhr.responseText;
		  document.getElementById("userid").innerHTML=response;
      } else {
          // Request failure: something bad happened
      }
    }
  };

  xhr.open('GET',GITHUB_USER_URL, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  //alert(google.getAccessToken());
  document.getElementById("token").innerHTML=google.getAccessToken();
  xhr.setRequestHeader('Authorization', 'OAuth '+ google.getAccessToken());
  xhr.send();
});

