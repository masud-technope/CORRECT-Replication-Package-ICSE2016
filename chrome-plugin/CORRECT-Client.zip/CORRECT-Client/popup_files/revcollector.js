// Copyright (c) 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * Get the current URL.
 * 
 * @param {function(string)}
 *            callback - called when the URL of the current tab is found.
 */

var start;

var lastBrowsedURL = null;

var topk=5;

var getCurrentTabUrl = function(callback) {

	// timer starts here
	start = new Date().getTime();

	var queryInfo = {
		active : true,
		currentWindow : true
	};

	chrome.tabs.query(queryInfo, function(tabs) {
		var tab = tabs[0];
		var url = tab.url;
		console.assert(typeof url == "string", "tab.url should be a string");
		callback(url);
	});
};

var renderStatus = function(statusText) {
	document.getElementById("status").textContent = statusText;
};

var renderTime = function(timingText) {
	document.getElementById("timing").textContent = timingText;
};

var showButton = function(buttonName) {
	document.getElementById(buttonName).style.display = "block";
};

var hideButton = function(buttonName) {
	document.getElementById(buttonName).style.display = "none";
};

var getSelectedRevs=function(tabName)
{
	var selectedRevs="";
	for(var index=0;index<5;index++){
		var checkbox=document.getElementById("check-"+index);
		if(checkbox.checked){
		selectedRevs+=  "@"+checkbox.value+" ";
		//console.log(document.getElementById("check-"+index).value);
		}
	}
	return selectedRevs;
};


var correctrecommender = {

	getCodeReviewers : function(url, reviewerTextAreaName) {

		// preparing the search query
		//var baseURL = "http://localhost:8080/wscorrect/CoRReCT_app?";
		var baseURL="http://srlabg53-2.usask.ca/wscorrect/CoRReCT_app?";

		var accessToken = document.getElementById("token").innerHTML;
		var prnumber = document.getElementById("prnumber").innerHTML;

		var searchUrl = baseURL + "branchurl=" + url + "&access_token="
				+ accessToken + "&prnumber=" + prnumber;
				
		//adding top-K
		var topkSize=document.getElementById("topkSizeData").value;
		searchUrl+="&topk="+topkSize;
		//storing in global variable
		topk=topkSize;
		
		//collecting training size
		var trainSize=document.getElementById("trainSizeData").value;
		searchUrl+="&tsize="+trainSize;
				
		// logging the accessed URL
		console.log(searchUrl);
		lastBrowsedURL = url;

		var xx = new XMLHttpRequest();
		xx.open("GET", searchUrl, true);
		xx.responseType = "text/json";
		xx.onload = this.showReviewers.bind(this);
		xx.send(null);
	},

	showReviewers : function(e) {
		var result = e.target.responseText;
		console.log(result);
		if (!result) {
			renderStatus("Failed to collect code reviewers!");
			return;

		} else {
			
			var prnumber = document.getElementById("prnumber").innerHTML;
			// process the JSON output
			// result=processJSON(result);

			if (!prnumber) {

				// var revResult = document.getElementById("reviewers-1");
				// revResult.textContent = result;
				// revResult.hidden = false;
				var resp=displayResults("reviewers-1", result);
				
				if(resp){
					//report the error message
					renderStatus(resp);
					return;
				}
				

				// var copy = document.getElementById("copy-1");
				// copy.style.display = "block";
				showButton("copy-1");
				hideButton("collect-1");

				var data2Extension = {
					option : 1,
					reviewers : result,
					prnum : prnumber,
					lastBrowsed : lastBrowsedURL
				};

				// signal the data to background page
				chrome.extension.sendMessage(data2Extension,
						function(response) {
							if (response.success)
								console.log("Results saved successfully!");
							else
								console.log("Failed to save the results");
						});

			} else {

				var resp=displayResults("reviewers-2", result);
				
				if(resp){
					//report the error message
					renderStatus(resp);
					return;
				}

				// var revResult = document.getElementById("reviewers-2");
				// revResult.textContent = result;
				// revResult.hidden = false;

				showButton("copy-2");
				hideButton("collect-2");

				var data2Extension = {
					option : 2,
					reviewers : result,
					prnum : prnumber,
					lastBrowsed : lastBrowsedURL
				};

				console.log(data2Extension);

				// signal the data to background page
				chrome.extension.sendMessage(data2Extension,
						function(response) {
							if (response)
								console.log("Results saved successfully!");
							else
								console.log("Failed to save the results");
						});
			}
			

			renderStatus("Top-"+topk+" reviewers recommended successfully!");

			// timer ends here
			var end = new Date().getTime();
			var delay = (end - start) / 1000;
			// reporting the time delay
			renderTime("Time required: " + delay + " seconds");
		}
	}
};

$(document).ready(function() {
	// new PR
	document.getElementById("collect-1").addEventListener("click", function() {
		console.log("Processing a new PR ...");
		renderStatus("Processing a new PR ...");
		attachButtonHandler("copy-1", "reviewers-1");
		// attachCopyHandler();
		getCurrentTabUrl(function(url) {
			correctrecommender.getCodeReviewers(url, "reviewers-1");
		});
	}, function(errorMessage) {
		renderStatus("Cannot show reviewers- " + errorMessage);
	});

	// existing PR
	document.getElementById("collect-2").addEventListener("click", function() {
		console.log("Processing an existing PR ...");
		renderStatus("Processing an existing PR ...");
		attachButtonHandler("copy-2", "reviewers-2");
		// attachCopyHandler();
		getCurrentTabUrl(function(url) {
			correctrecommender.getCodeReviewers(url, "reviewers-2");
		});
	}, function(errorMessage) {
		renderStatus("Cannot show reviewers- " + errorMessage);
	});
});

var attachButtonHandler = function(copyButtonID, reviewersTextAreaID) {
	// adding click handler for the button
	var copyButton = document.getElementById(copyButtonID);
	copyButton.addEventListener("click", function() {
		//alert("I am clicked");
		// var revResult = document.getElementById(reviewersTextAreaID);
		var revResult = document.getElementById("revcache");
		revResult.style.display="block";
		revResult.value=getSelectedRevs(null);
		console.log("Selected code reviewers:");
		console.log(getSelectedRevs(null));
		revResult.select();
		//copying the data to the clipboard
		document.execCommand("copy");
		//do not pass the event downwards
		return false;
	}); 
	
	
	
	
	
	//copyButton.addEventListener("click",copyRevs);
	
	
};

// old code-- not using right now
/*
 * document.addEventListener('DOMContentLoaded', function() {
 * renderStatus('Processing request ...'); attachButtonHandler();
 * //attachCopyHandler(); getCurrentTabUrl(function(url){
 * correctrecommender.getCodeReviewers(url); }); }, function(errorMessage) {
 * renderStatus('Cannot display reviewers. ' + errorMessage); });
 */

/*
 * var attachCopyHandler=function(){
 * document.addEventListener("copy",function(e){ var revResult =
 * document.getElementById('reviewers'); e.clipboardData.setData('text/plain',
 * revResult.textContent); }); }
 */
