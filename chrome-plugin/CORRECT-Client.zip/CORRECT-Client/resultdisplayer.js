var processJSON = function(jsonContent) {
	var result = new String();
	var revs = JSON.parse(jsonContent);
	for (var index = 0; index < revs.length; index++) {
		var rev = revs[index];
		result += "<tr><td><input type='checkbox' id='check-"+ index+"'  name='check-"+ index+"' value='" + rev.login+"'>"+rev.login+ "</td><td>"
				+   Math.ceil(parseFloat(rev.libSimScore) * 100) + "%"
				+ "</td><td>" + Math.ceil(parseFloat(rev.techSimScore)* 100)+ "%"
				+ "</td><td>"+ Math.ceil(parseFloat(rev.miscSimScore)* 100)+ "%"
				+ "</td><td>" + Math.ceil(parseFloat(rev.totalScore) * 100)  + "%" + "</td></tr>";
	}
	return result;
};

var displayResults = function(containerDiv, jsonContent) {
	try{
	var content = "<table border='1' cellspacing='0' cellpadding='2' width='350'>";
	content += "<tr><th width='150'>Reviewer</th><th title='Vendasta library similarity'>VLS</th><th title='Specialized technology similarity'>STS</th><th title='Miscellaneous library similarity' >MLS</th><th title='Total score'>TS</th></tr>";
	content += processJSON(jsonContent);
	content += "</table>";
	document.getElementById(containerDiv).innerHTML = content;
	// also make a browser cache
	makePageCache(jsonContent);
	}catch(e){
		//returning the error message
		return jsonContent;
	}
};

var makePageCache = function(jsonContent) {
	var logins = new String();
	var revs = JSON.parse(jsonContent);
	for (var index = 0; index < revs.length; index++) {
		var rev = revs[index];
		logins += "@" + rev.login + " ";
	}
	// now store them in page cache
	document.getElementById("revcache").value = logins;
};

var refreshResults = function(containerDiv) {
	document.getElementById(containerDiv).innerHTML = "";
	//clearing local storage
	localStorage["prnum"] = "";
	localStorage["reviewers"] = "";
	localStorage["option"] = "";
	localStorage["lastBrowsed"] = "";
};
