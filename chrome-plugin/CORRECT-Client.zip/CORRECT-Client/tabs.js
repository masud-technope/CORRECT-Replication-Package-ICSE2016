// JavaScript Document
$(function() {
	$("#tabs").tabs();

	// getting current URL
	var queryInfo = {
		active : true,
		currentWindow : true
	};
	
	var attachButtonHandler = function(copyButtonID, reviewersTextAreaID) {
	// adding click handler for the button
	var copyButton = document.getElementById(copyButtonID);
	copyButton.addEventListener("click", function() {
		//alert("I am clicked");
		// var revResult = document.getElementById(reviewersTextAreaID);
		var revResult = document.getElementById("revcache");
		revResult.style.display="block";
		revResult.value=getSelectedRevs(null);
		console.log("Selected code reviewers:");
		console.log(getSelectedRevs(null));
		revResult.select();
		//copying the data to the clipboard
		document.execCommand("copy");
		//do not pass the event downwards
		return false;
	}); 
	};
		
	chrome.tabs
			.query(
					queryInfo,
					function(tabs) {
						var tab = tabs[0];
						var url = tab.url;
						var numRegex = "\\/\\d+";

						var temp = url.match(numRegex);
						var prnumber = null;
						if (temp) {
							prnumber = temp[0].substring(1);
						}

						if (prnumber) {
							$("#tabs").tabs("option", "active", 1);
							document.getElementById("prnumber").innerHTML = prnumber;
							var lastBrowsed = localStorage["lastBrowsed"];
							if (lastBrowsed) {
								if (lastBrowsed.localeCompare(url) == 0) {
									var reviewers = localStorage["reviewers"];
									//document.getElementById("reviewers-2").textContent = reviewers;
									displayResults("reviewers-2", reviewers);
									//attach the handler to copy button
									attachButtonHandler("copy-2", "reviewers-2");
									showButton("copy-2");
									hideButton("collect-2");

								}
							}else{
								refreshResults("reviewers-2");
								hideButton("copy-2");
								showButton("collect-2");
							}
							
						} else {
							$("#tabs").tabs("option", "active", 0);
							
							var parts = url.split("/");
							this.repoName = parts[parts.length - 3];
							var branchNames = parts[parts.length - 1];
							var brparts = branchNames.split("...");
							if (brparts.length == 2) {
								branch1 = brparts[0];
								branch2 = brparts[1];
								if(branch2.indexOf('?')>0){
									var moreparts=branch2.split("?");
									branch2=moreparts[0];
								}
							} else {
								branch1 = "develop";
								branch2 = branchNames;
								if(branch2.indexOf('?')>0){
									var moreparts=branch2.split("?");
									branch2=moreparts[0];
								}
							}
							
							
							console.log(branch1+" "+branch2);
							//now show those two branches
							document.getElementById("main").innerHTML=branch1;
							document.getElementById("branch").innerHTML=branch2;
							
							var lastBrowsed = localStorage["lastBrowsed"];
							if (lastBrowsed) {
								if (lastBrowsed.localeCompare(url) == 0) {
									var reviewers = localStorage["reviewers"];
									displayResults("reviewers-1", reviewers);
									//document.getElementById("reviewers-1").textContent = reviewers;
									showButton("copy-1");
									hideButton("collect-1");
									//attach the handler to copy button
									attachButtonHandler("copy-1", "reviewers-1");

								}
							}else{
								refreshResults("reviewers-1");
								hideButton("copy-1");
								showButton("collect-1");
							}
						}
						
						//adding handler to refresh button
						$("#refresh-1").click(function(){
							refreshResults("reviewers-1");
							hideButton("copy-1");
							showButton("collect-1");
						});
						
						//adding handler to refresh button
						$("#refresh-2").click(function(){
							refreshResults("reviewers-2");
							hideButton("copy-2");
							showButton("collect-2");
						});
						
					});
			
			
			//adding progress bar
			   $("#trainSize").slider({
					min: 10,
					max: 50,
					step: 10,
					slide: function (event, ui) {
						$(this).parent().find("#trainSizeData").val(ui.value);
						$(this).attr("title",ui.value);
						localStorage["tsize"]=ui.value;
					},
					create: function(event, ui){
						$(this).parent().find("#trainSizeData").val(localStorage["tsize"]);
						$(this).slider('value',$(this).parent().find("#trainSizeData").val());
					}
				});
			   
			   
			   
			   $("#topkSize").slider({
					min: 5,
					max: 15,
					step: 5,
					slide: function (event, ui) {
						$(this).parent().find("#topkSizeData").val(ui.value);
						$(this).attr("title",ui.value);
						localStorage["topk"]=ui.value;
						
					},
					create: function(event, ui){
						$(this).parent().find("#topkSizeData").val(localStorage["topk"]);
						$(this).slider('value',$(this).parent().find("#topkSizeData").val());
					}
				});
			
			

});
