chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
	console.log(request);
	// console.log(sender);
	var succeed = null;
	if (request.reviewers) {
		// chrome.storage.local.set(data, function() {
		localStorage["prnum"] = request.prnum;
		localStorage["reviewers"] = request.reviewers;
		localStorage["option"] = request.option;
		localStorage["lastBrowsed"] = request.lastBrowsed;
		// });
		succeed = true;
	}
	return succeed;
}
);