var copyRevs = function() {
	// copying the reviewers to pull request body
	var revResult = document.getElementById("revcache").innerHTML;
	document.getElementById("pull_request_body").innerHTML = revResult;
};