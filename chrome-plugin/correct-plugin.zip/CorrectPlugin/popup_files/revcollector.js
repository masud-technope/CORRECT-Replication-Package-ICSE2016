// Copyright (c) 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * Get the current URL.
 *
 * @param {function(string)} callback - called when the URL of the current tab
 *   is found.
 **/

var start;

var getCurrentTabUrl=function(callback) {
  
  //timer starts here
  start=new Date().getTime();
  
  var currenturl;
  var queryInfo = {
    active: true,
    currentWindow: true
  };
  
  chrome.tabs.query(queryInfo, function(tabs) {
    var tab = tabs[0];
    var url = tab.url;
    //assigning the current url
    //currenturl=url;
    console.assert(typeof url == 'string', 'tab.url should be a string');
    callback(url);
  });
}

var renderStatus=function(statusText) {
  document.getElementById('status').textContent = statusText;
}

var renderTime=function(timingText){
document.getElementById('timing').textContent=timingText;
}


var correctrecommender={

 getCodeReviewers: function(url)
 {
	var revResult = document.getElementById('reviewers');
	if(revResult.textContent){
		//do nothing, just show the previously collected reviewers
		return;
	}
	
	//var searchUrl='http://localhost:8080/wscorrect/CoRReCT_app?branchurl='+url;
	var searchUrl='http://srlabg53-2.usask.ca/wscorrect/CoRReCT_app?branchurl='+url;
	
	console.log(searchUrl);
	//var searchUrl='http://localhost:8080/wssurfclipse/surfclipse_app?query=IOException';
	//document.getElementById('reviewers').innerHTML=searchUrl;
	//var searchUrl="http://www.google.ca";

	var xx = new XMLHttpRequest();
  	xx.open('GET', searchUrl,true);
  	xx.responseType = 'text/html';
	xx.onload = this.showReviewers.bind(this);
    xx.send(null);
 },

showReviewers: function(e){
		//var response = e.target; //xx.response; //e.target.responseXML.querySelectorAll('photo');

		var result=e.target.responseText;
		console.log(result);

		if(!result){
			renderStatus('Failed to collect reviewers.');
			return;
		}else{
					renderStatus('Reviewers recommended:');
					var revResult = document.getElementById('reviewers');
					revResult.textContent=result;
					revResult.hidden=false;
					
					var copy=document.getElementById("copy");
					copy.style.display="block";
					
					//timer ends here
					var end=new Date().getTime();
					var delay=(end-start)/1000;
					//reporting the time delay
					renderTime('Time required: '+delay+' s');
			}
	}
};

document.addEventListener('DOMContentLoaded', function() {
	renderStatus('Processing request ...');
	attachButtonHandler();
	//attachCopyHandler();
	getCurrentTabUrl(function(url){
		correctrecommender.getCodeReviewers(url);
		});
	}, function(errorMessage) {
      renderStatus('Cannot display reviewers. ' + errorMessage);
  });


var attachButtonHandler=function(){
//adding click handler for the button
var copyButton=document.getElementById("copy");
copyButton.addEventListener("click", function(){
	//alert("I am clicked");
	var revResult = document.getElementById('reviewers');
	revResult.select();
	document.execCommand("copy");
});
}

/*var attachCopyHandler=function(){
	document.addEventListener("copy",function(e){
	var revResult = document.getElementById('reviewers');
	 e.clipboardData.setData('text/plain', revResult.textContent);											  
});
}*/






	







